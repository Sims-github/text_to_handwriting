import pywhatkit
pywhatkit.text_to_handwriting("Hii rachhu, always be happy :-)")
